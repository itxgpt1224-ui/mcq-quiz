class McqOption {
  final String label;
  final String text;

  const McqOption({required this.label, required this.text});

  factory McqOption.fromJson(Map<String, dynamic> j) => McqOption(
        label: '${j['label'] ?? ''}'.trim(),
        text: '${j['text'] ?? ''}',
      );

  Map<String, dynamic> toJson() => {'label': label, 'text': text};
}

class Mcq {
  /// Number jaisa PDF mein likha hai (e.g. "1", "Q12").
  final String number;
  final String question;
  final List<McqOption> options;

  /// Sahi option labels. Ek se zyada ho to double/multiple answer MCQ.
  /// Khali ho to PDF mein is sawal ka answer nahi mila.
  final List<String> correct;

  const Mcq({
    required this.number,
    required this.question,
    required this.options,
    required this.correct,
  });

  bool get isMulti => correct.length > 1;
  bool get hasKey => correct.isNotEmpty;

  factory Mcq.fromJson(Map<String, dynamic> j) {
    final opts = (j['options'] as List? ?? [])
        .whereType<Map>()
        .map((e) => McqOption.fromJson(Map<String, dynamic>.from(e)))
        .toList();
    final correct = (j['correct'] as List? ?? [])
        .map((e) => '$e'.trim().toUpperCase())
        .where((e) => e.isNotEmpty)
        .toSet()
        .toList();
    return Mcq(
      number: '${j['number'] ?? ''}'.trim(),
      question: '${j['question'] ?? ''}',
      options: opts,
      correct: correct,
    );
  }

  Map<String, dynamic> toJson() => {
        'number': number,
        'question': question,
        'options': options.map((o) => o.toJson()).toList(),
        'correct': correct,
      };
}

class SavedQuiz {
  final String title;
  final DateTime createdAt;
  final List<Mcq> questions;

  const SavedQuiz({
    required this.title,
    required this.createdAt,
    required this.questions,
  });

  factory SavedQuiz.fromJson(Map<String, dynamic> j) => SavedQuiz(
        title: '${j['title'] ?? 'Quiz'}',
        createdAt: DateTime.tryParse('${j['createdAt']}') ?? DateTime.now(),
        questions: (j['questions'] as List? ?? [])
            .whereType<Map>()
            .map((e) => Mcq.fromJson(Map<String, dynamic>.from(e)))
            .toList(),
      );

  Map<String, dynamic> toJson() => {
        'title': title,
        'createdAt': createdAt.toIso8601String(),
        'questions': questions.map((q) => q.toJson()).toList(),
      };
}
