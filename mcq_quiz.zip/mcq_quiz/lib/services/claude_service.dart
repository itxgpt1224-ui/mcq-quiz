import 'dart:convert';
import 'dart:typed_data';

import 'package:http/http.dart' as http;

import '../models/mcq.dart';

class ClaudeException implements Exception {
  final String message;
  ClaudeException(this.message);
  @override
  String toString() => message;
}

/// PDF ko Claude API ko bhejta hai aur MCQs + answer key wapas leta hai.
/// Lambe PDF ke liye MCQs chhote batches mein nikalta hai, taake koi sawal
/// output limit ki wajah se adhoora ya gayab na ho.
class ClaudeService {
  final String apiKey;
  final String model;

  ClaudeService({required this.apiKey, required this.model});

  static const _batchSize = 25;
  static const _maxBatches = 80;

  static const _system = '''
You are a precise MCQ extraction engine. You read a PDF containing multiple-choice questions and an answer key, and you return them as JSON.

RULES
1. Copy each question text and each option text EXACTLY word for word as printed in the PDF. Keep the original spelling, punctuation, numbers, symbols, capitalisation and even mistakes. Never paraphrase, translate, correct, shorten or reorder.
2. Include EVERY option that exists for a question. Some questions have options A-B only, some A-C, some A-D, some A-E or more. Never invent a missing option and never drop an existing one.
3. Find the answer key wherever it is (end of the PDF, a table, beside each question, "Ans:" lines, etc.) and put the correct option letter(s) of each question in "correct". If a question has more than one correct answer (for example "A and C", "AC", "A,C", "both A and B"), list ALL the letters. If the key gives the option text instead of a letter, map it to the matching letter. If no answer can be found for a question, use an empty list. Never guess an answer.
4. Use option labels exactly as printed, in upper case (A, B, C ...). If options are numbered 1,2,3 or (i),(ii), keep them as printed.
5. "number" is the question number exactly as printed.
6. Do not treat headings, instructions, explanations or the answer key itself as questions.
7. Output ONLY one JSON object, no markdown fences, no commentary.

JSON SHAPE
{
  "questions": [
    {
      "number": "1",
      "question": "...",
      "options": [ {"label": "A", "text": "..."}, {"label": "B", "text": "..."} ],
      "correct": ["B"]
    }
  ],
  "has_more": false
}
''';

  Future<List<Mcq>> extract(
    Uint8List pdfBytes, {
    void Function(int count)? onProgress,
  }) async {
    final b64 = base64Encode(pdfBytes);
    final all = <Mcq>[];

    for (var i = 0; i < _maxBatches; i++) {
      final res = await _callOnce(b64, skip: all.length);
      if (res.questions.isEmpty) break;
      all.addAll(res.questions);
      onProgress?.call(all.length);
      if (!res.hasMore) break;
    }

    if (all.isEmpty) {
      throw ClaudeException('Is PDF mein koi MCQ nahi mila.');
    }
    return all;
  }

  Future<({List<Mcq> questions, bool hasMore})> _callOnce(
    String b64, {
    required int skip,
  }) async {
    final instruction = skip == 0
        ? 'Extract the first $_batchSize MCQs from this PDF, in the order they appear. '
            'Set "has_more" to true if more MCQs remain after these.'
        : 'The first $skip MCQs of this PDF were already extracted. Skip them and '
            'extract the NEXT $_batchSize MCQs, in the order they appear. '
            'Set "has_more" to true if more MCQs remain after these, otherwise false.';

    final body = jsonEncode({
      'model': model,
      'max_tokens': 16000,
      'system': _system,
      'messages': [
        {
          'role': 'user',
          'content': [
            {
              'type': 'document',
              'source': {
                'type': 'base64',
                'media_type': 'application/pdf',
                'data': b64,
              },
            },
            {'type': 'text', 'text': instruction},
          ],
        },
      ],
    });

    final http.Response resp;
    try {
      resp = await http
          .post(
            Uri.parse('https://api.anthropic.com/v1/messages'),
            headers: {
              'x-api-key': apiKey,
              'anthropic-version': '2023-06-01',
              'content-type': 'application/json',
            },
            body: body,
          )
          .timeout(const Duration(minutes: 5));
    } catch (e) {
      throw ClaudeException('Internet ya server ka masla: $e');
    }

    final decoded = jsonDecode(utf8.decode(resp.bodyBytes));
    if (resp.statusCode != 200) {
      final msg = decoded is Map
          ? (decoded['error']?['message'] ?? resp.body)
          : resp.body;
      if (resp.statusCode == 401) {
        throw ClaudeException('API key galat hai. Settings mein check karein.');
      }
      throw ClaudeException('API error ${resp.statusCode}: $msg');
    }

    final text = (decoded['content'] as List)
        .whereType<Map>()
        .where((b) => b['type'] == 'text')
        .map((b) => '${b['text']}')
        .join();

    final start = text.indexOf('{');
    final end = text.lastIndexOf('}');
    if (start < 0 || end <= start) {
      throw ClaudeException('Jawab samajh nahi aaya. Dobara koshish karein.');
    }

    try {
      final json = jsonDecode(text.substring(start, end + 1));
      final qs = (json['questions'] as List? ?? [])
          .whereType<Map>()
          .map((e) => Mcq.fromJson(Map<String, dynamic>.from(e)))
          .where((q) => q.question.trim().isNotEmpty && q.options.isNotEmpty)
          .toList();
      return (questions: qs, hasMore: json['has_more'] == true);
    } catch (_) {
      throw ClaudeException(
          'MCQs ka data adhoora aaya. Dobara koshish karein ya chhota PDF dein.');
    }
  }
}
