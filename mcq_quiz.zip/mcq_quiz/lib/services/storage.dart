import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import '../models/mcq.dart';

class AppStorage {
  static const _kKey = 'api_key';
  static const _kModel = 'model';
  static const _kQuizzes = 'saved_quizzes';

  static const models = [
    'claude-sonnet-5-5',
    'claude-opus-5-5',
    'claude-haiku-5-5',
  ];

  static Future<String> getApiKey() async =>
      (await SharedPreferences.getInstance()).getString(_kKey) ?? '';

  static Future<void> setApiKey(String v) async =>
      (await SharedPreferences.getInstance()).setString(_kKey, v.trim());

  static Future<String> getModel() async =>
      (await SharedPreferences.getInstance()).getString(_kModel) ?? models.first;

  static Future<void> setModel(String v) async =>
      (await SharedPreferences.getInstance()).setString(_kModel, v);

  static Future<List<SavedQuiz>> loadQuizzes() async {
    final raw = (await SharedPreferences.getInstance()).getString(_kQuizzes);
    if (raw == null) return [];
    try {
      return (jsonDecode(raw) as List)
          .whereType<Map>()
          .map((e) => SavedQuiz.fromJson(Map<String, dynamic>.from(e)))
          .toList();
    } catch (_) {
      return [];
    }
  }

  static Future<void> _write(List<SavedQuiz> list) async =>
      (await SharedPreferences.getInstance())
          .setString(_kQuizzes, jsonEncode(list.map((q) => q.toJson()).toList()));

  static Future<void> addQuiz(SavedQuiz quiz) async {
    final list = await loadQuizzes();
    list.insert(0, quiz);
    await _write(list);
  }

  static Future<void> deleteQuiz(int index) async {
    final list = await loadQuizzes();
    if (index >= 0 && index < list.length) {
      list.removeAt(index);
      await _write(list);
    }
  }
}
