import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';

import '../models/mcq.dart';
import '../services/claude_service.dart';
import '../services/storage.dart';
import 'quiz_screen.dart';
import 'settings_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<SavedQuiz> _saved = [];
  bool _busy = false;
  String _status = '';

  @override
  void initState() {
    super.initState();
    _loadSaved();
  }

  Future<void> _loadSaved() async {
    final list = await AppStorage.loadQuizzes();
    if (mounted) setState(() => _saved = list);
  }

  void _snack(String msg) => ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(content: Text(msg)));

  Future<void> _pickAndScan() async {
    final apiKey = await AppStorage.getApiKey();
    if (apiKey.isEmpty) {
      _snack('Pehle Settings mein API key daalein.');
      if (!mounted) return;
      await Navigator.push(
          context, MaterialPageRoute(builder: (_) => const SettingsScreen()));
      return;
    }

    final picked = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['pdf'],
      withData: true,
    );
    if (picked == null || picked.files.isEmpty) return;
    final file = picked.files.first;
    final bytes = file.bytes;
    if (bytes == null) {
      _snack('File padh nahi saka.');
      return;
    }

    setState(() {
      _busy = true;
      _status = 'PDF scan ho raha hai...';
    });

    try {
      final model = await AppStorage.getModel();
      final service = ClaudeService(apiKey: apiKey, model: model);
      final questions = await service.extract(
        bytes,
        onProgress: (n) {
          if (mounted) setState(() => _status = '$n MCQs mil gaye, scan jaari...');
        },
      );

      final quiz = SavedQuiz(
        title: file.name.replaceAll(RegExp(r'\.pdf$', caseSensitive: false), ''),
        createdAt: DateTime.now(),
        questions: questions,
      );
      await AppStorage.addQuiz(quiz);
      await _loadSaved();

      if (!mounted) return;
      final missing = questions.where((q) => !q.hasKey).length;
      if (missing > 0) {
        _snack('$missing sawalon ka answer PDF mein nahi mila.');
      }
      _open(quiz);
    } on ClaudeException catch (e) {
      _snack(e.message);
    } catch (e) {
      _snack('Masla aa gaya: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  void _open(SavedQuiz quiz) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => QuizScreen(quiz: quiz)),
    );
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(
        title: const Text('MCQ Quiz Maker'),
        actions: [
          IconButton(
            icon: const Icon(Icons.settings),
            onPressed: () async {
              await Navigator.push(context,
                  MaterialPageRoute(builder: (_) => const SettingsScreen()));
            },
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                style: FilledButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 18)),
                onPressed: _busy ? null : _pickAndScan,
                icon: _busy
                    ? const SizedBox(
                        width: 18,
                        height: 18,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : const Icon(Icons.upload_file),
                label: Text(_busy ? _status : 'PDF upload karein'),
              ),
            ),
          ),
          if (_busy)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24),
              child: Text(
                'Bade PDF mein kuch minute lag sakte hain. App band na karein.',
                style: TextStyle(color: cs.onSurfaceVariant),
                textAlign: TextAlign.center,
              ),
            ),
          const Divider(),
          Expanded(
            child: _saved.isEmpty
                ? Center(
                    child: Text(
                      'Abhi koi quiz nahi.\nPDF upload karke shuru karein.',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: cs.onSurfaceVariant),
                    ),
                  )
                : ListView.builder(
                    itemCount: _saved.length,
                    itemBuilder: (_, i) {
                      final q = _saved[i];
                      return Dismissible(
                        key: ValueKey('${q.title}${q.createdAt}'),
                        direction: DismissDirection.endToStart,
                        background: Container(
                          color: Colors.red,
                          alignment: Alignment.centerRight,
                          padding: const EdgeInsets.only(right: 20),
                          child: const Icon(Icons.delete, color: Colors.white),
                        ),
                        onDismissed: (_) async {
                          await AppStorage.deleteQuiz(i);
                          await _loadSaved();
                        },
                        child: ListTile(
                          leading: const Icon(Icons.quiz),
                          title: Text(q.title),
                          subtitle: Text('${q.questions.length} MCQs'),
                          onTap: () => _open(q),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}
