import 'package:flutter/material.dart';

import '../models/mcq.dart';
import 'quiz_screen.dart';

class ResultScreen extends StatelessWidget {
  final SavedQuiz quiz;
  final int score;
  final int scorable;
  final List<int> wrongIndexes;
  final Map<int, List<String>> picked;

  const ResultScreen({
    super.key,
    required this.quiz,
    required this.score,
    required this.scorable,
    required this.wrongIndexes,
    required this.picked,
  });

  @override
  Widget build(BuildContext context) {
    final percent = scorable == 0 ? 0 : (score * 100 / scorable).round();
    return Scaffold(
      appBar: AppBar(title: const Text('Result')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Center(
            child: Column(
              children: [
                Text('$score / $scorable',
                    style: Theme.of(context)
                        .textTheme
                        .displaySmall
                        ?.copyWith(fontWeight: FontWeight.bold)),
                Text('$percent%', style: Theme.of(context).textTheme.titleLarge),
              ],
            ),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: FilledButton(
                  onPressed: () => Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(builder: (_) => QuizScreen(quiz: quiz)),
                  ),
                  child: const Text('Dobara khelein'),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: OutlinedButton(
                  onPressed: () =>
                      Navigator.popUntil(context, (r) => r.isFirst),
                  child: const Text('Home'),
                ),
              ),
            ],
          ),
          if (wrongIndexes.isNotEmpty) ...[
            const SizedBox(height: 24),
            Text('Galat jawab', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 8),
            for (final i in wrongIndexes)
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Q${quiz.questions[i].number}: ${quiz.questions[i].question}'),
                      const SizedBox(height: 6),
                      Text(
                        'Aap ka jawab: ${(picked[i] ?? []).isEmpty ? "-" : picked[i]!.join(", ")}',
                        style: const TextStyle(color: Colors.red),
                      ),
                      Text(
                        'Sahi jawab: ${quiz.questions[i].correct.join(", ")}',
                        style: const TextStyle(color: Colors.green),
                      ),
                    ],
                  ),
                ),
              ),
          ],
        ],
      ),
    );
  }
}
