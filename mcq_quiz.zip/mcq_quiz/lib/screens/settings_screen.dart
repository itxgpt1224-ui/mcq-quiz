import 'package:flutter/material.dart';

import '../services/storage.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final _keyCtrl = TextEditingController();
  String _model = AppStorage.models.first;
  bool _hide = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final k = await AppStorage.getApiKey();
    final m = await AppStorage.getModel();
    if (!mounted) return;
    setState(() {
      _keyCtrl.text = k;
      _model = AppStorage.models.contains(m) ? m : AppStorage.models.first;
    });
  }

  Future<void> _save() async {
    await AppStorage.setApiKey(_keyCtrl.text);
    await AppStorage.setModel(_model);
    if (!mounted) return;
    ScaffoldMessenger.of(context)
        .showSnackBar(const SnackBar(content: Text('Save ho gaya')));
    Navigator.pop(context);
  }

  @override
  void dispose() {
    _keyCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          TextField(
            controller: _keyCtrl,
            obscureText: _hide,
            decoration: InputDecoration(
              labelText: 'Claude API key',
              hintText: 'sk-ant-...',
              border: const OutlineInputBorder(),
              suffixIcon: IconButton(
                icon: Icon(_hide ? Icons.visibility : Icons.visibility_off),
                onPressed: () => setState(() => _hide = !_hide),
              ),
            ),
          ),
          const SizedBox(height: 4),
          const Text(
            'Key console.anthropic.com se milti hai. Ye sirf aap ke phone mein save hoti hai.',
            style: TextStyle(fontSize: 12, color: Colors.grey),
          ),
          const SizedBox(height: 20),
          DropdownButtonFormField<String>(
            value: _model,
            decoration: const InputDecoration(
              labelText: 'Model',
              border: OutlineInputBorder(),
            ),
            items: [
              for (final m in AppStorage.models)
                DropdownMenuItem(value: m, child: Text(m)),
            ],
            onChanged: (v) => setState(() => _model = v ?? _model),
          ),
          const SizedBox(height: 4),
          const Text(
            'Sonnet: tez aur sasta (default). Opus: sabse accurate, mushkil ya scanned PDF ke liye.',
            style: TextStyle(fontSize: 12, color: Colors.grey),
          ),
          const SizedBox(height: 24),
          FilledButton(onPressed: _save, child: const Text('Save')),
        ],
      ),
    );
  }
}
