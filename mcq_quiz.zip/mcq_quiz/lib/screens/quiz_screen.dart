import 'package:flutter/material.dart';

import '../models/mcq.dart';
import 'result_screen.dart';

class QuizScreen extends StatefulWidget {
  final SavedQuiz quiz;
  const QuizScreen({super.key, required this.quiz});

  @override
  State<QuizScreen> createState() => _QuizScreenState();
}

class _QuizScreenState extends State<QuizScreen> {
  int _index = 0;

  /// Har sawal ke liye user ke tap kiye hue option labels.
  final Map<int, List<String>> _picked = {};

  List<Mcq> get _qs => widget.quiz.questions;
  Mcq get _q => _qs[_index];

  bool _done(int i) {
    final q = _qs[i];
    final p = _picked[i] ?? const [];
    if (!q.hasKey) return p.isNotEmpty;
    return p.length >= q.correct.length;
  }

  bool _isRight(int i) {
    final q = _qs[i];
    final p = (_picked[i] ?? const []).toSet();
    return q.hasKey && p.length == q.correct.length && p.containsAll(q.correct);
  }

  void _tap(String label) {
    if (_done(_index)) return;
    final p = _picked.putIfAbsent(_index, () => []);
    if (p.contains(label)) return;
    setState(() => p.add(label));
  }

  Color? _bg(String label) {
    final p = _picked[_index] ?? const [];
    final q = _q;
    if (!q.hasKey) {
      return p.contains(label) ? Colors.blue.withOpacity(0.25) : null;
    }
    if (p.contains(label)) {
      return q.correct.contains(label)
          ? Colors.green.withOpacity(0.35)
          : Colors.red.withOpacity(0.35);
    }
    // Jawab mukammal hone par sahi option bhi green dikhao.
    if (_done(_index) && q.correct.contains(label)) {
      return Colors.green.withOpacity(0.35);
    }
    return null;
  }

  Color _border(String label) {
    final p = _picked[_index] ?? const [];
    final q = _q;
    if (!q.hasKey) {
      return p.contains(label) ? Colors.blue : Colors.grey.shade400;
    }
    if (p.contains(label)) {
      return q.correct.contains(label) ? Colors.green : Colors.red;
    }
    if (_done(_index) && q.correct.contains(label)) return Colors.green;
    return Colors.grey.shade400;
  }

  void _next() {
    if (_index < _qs.length - 1) {
      setState(() => _index++);
    } else {
      _finish();
    }
  }

  void _finish() {
    final score = List.generate(_qs.length, (i) => i).where(_isRight).length;
    final wrong = <int>[
      for (var i = 0; i < _qs.length; i++)
        if (_qs[i].hasKey && !_isRight(i)) i
    ];
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (_) => ResultScreen(
          quiz: widget.quiz,
          score: score,
          scorable: _qs.where((q) => q.hasKey).length,
          wrongIndexes: wrong,
          picked: _picked,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final q = _q;

    return Scaffold(
      appBar: AppBar(
        title: Text('${_index + 1} / ${_qs.length}'),
        actions: [
          TextButton(onPressed: _finish, child: const Text('Khatam')),
        ],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(4),
          child: LinearProgressIndicator(value: (_index + 1) / _qs.length),
        ),
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView(
              padding: const EdgeInsets.all(16),
              children: [
                if (q.number.isNotEmpty)
                  Text('Q${q.number}',
                      style: Theme.of(context).textTheme.labelLarge),
                const SizedBox(height: 4),
                SelectableText(
                  q.question,
                  style: Theme.of(context)
                      .textTheme
                      .titleMedium
                      ?.copyWith(height: 1.4),
                ),
                if (q.isMulti)
                  Padding(
                    padding: const EdgeInsets.only(top: 8),
                    child: Text(
                      '${q.correct.length} jawab sahi hain, ${q.correct.length} option chunein.',
                      style: const TextStyle(
                          color: Colors.orange, fontWeight: FontWeight.w600),
                    ),
                  ),
                if (!q.hasKey)
                  const Padding(
                    padding: EdgeInsets.only(top: 8),
                    child: Text(
                      'Is sawal ka answer PDF mein nahi mila.',
                      style: TextStyle(color: Colors.grey),
                    ),
                  ),
                const SizedBox(height: 16),
                for (final o in q.options)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: InkWell(
                      borderRadius: BorderRadius.circular(12),
                      onTap: () => _tap(o.label),
                      child: Container(
                        padding: const EdgeInsets.all(14),
                        decoration: BoxDecoration(
                          color: _bg(o.label),
                          border: Border.all(color: _border(o.label), width: 1.5),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('${o.label}.  ',
                                style: const TextStyle(
                                    fontWeight: FontWeight.bold)),
                            Expanded(child: Text(o.text)),
                          ],
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Row(
                children: [
                  OutlinedButton(
                    onPressed:
                        _index == 0 ? null : () => setState(() => _index--),
                    child: const Text('Pichla'),
                  ),
                  const Spacer(),
                  FilledButton(
                    onPressed: _next,
                    child: Text(_index == _qs.length - 1 ? 'Result' : 'Agla'),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
