# MCQ Quiz Maker (Flutter, Android)

PDF upload karein, app MCQs aur answer key scan karke quiz bana deti hai.
Option tap karne par sahi = green, galat = red.

## Setup (ek baar)

1. Flutter install karein: https://docs.flutter.dev/get-started/install
2. Terminal mein:
   ```
   flutter create mcq_quiz
   ```
3. Is folder ki `lib/` aur `pubspec.yaml` ko naye `mcq_quiz` project mein copy (replace) karein.
4. `android/app/src/main/AndroidManifest.xml` mein `<application` se pehle ye line daalein (release APK mein internet ke liye zaroori):
   ```xml
   <uses-permission android:name="android.permission.INTERNET"/>
   ```
5. Run:
   ```
   flutter pub get
   flutter run
   ```
6. APK banane ke liye: `flutter build apk --release`

## GitHub se APK banakar phone par install karna (Flutter install kiye baghair)

1. github.com par naya repository banayein (e.g. `mcq-quiz`).
2. Is folder ki sari cheezein repository ke root mein upload karein: `lib/`, `pubspec.yaml`, `.github/`, `.gitignore`, `README.md`.
3. Repository ke **Actions** tab mein "Build APK" chalta nazar aayega (5-10 minute). Hara tick aane tak intezar karein.
4. Phone ke browser mein repository ka **Releases** section kholein, "Latest APK" se `app-release.apk` download karein.
5. Download ki hui file kholein aur "Install unknown apps" ki ijazat dein. Play Protect warning aaye to "Install anyway" dabayein.

Code badalne par naya push karein, APK khud dobara ban jati hai.

## Pehli baar istemal

1. Settings (gear icon) kholein, Claude API key daalein (console.anthropic.com se) aur Save karein.
2. "PDF upload karein" dabayein, PDF chunein, scan hone ka intezar karein.
3. Quiz khud khul jayegi. Purani quizzes home par save rehti hain (left swipe se delete).

## Kaise kaam karta hai

- PDF base64 mein Claude API ko jata hai (`document` block), 25-25 MCQs ke batch mein.
- Har MCQ ka text aur options word-to-word copy hote hain (A-B, A-C, A-D, A-E, jitne bhi hon).
- Answer key (end mein, table mein ya sawal ke saath) se sahi option(s) match hote hain, double answer wale sawalon mein dono letters.
- Jis sawal ka answer PDF mein na mile, wahan option neela (blue) hota hai, red/green nahi.

## Zaroori baatein

- Har scan par API charges lagte hain (PDF ke pages ke hisab se). Bade PDF ke liye Sonnet theek hai, mushkil ya scanned PDF ke liye Opus chunein.
- PDF password-protected nahi hona chahiye. Limit: 600 pages tak (ya 100 jab context window 1M se kam ho), request size 128 MB tak.
- 100% word-to-word accuracy ke liye Claude ko sakht hidayat di gayi hain, lekin AI kabhi kabhi galti kar sakta hai, khaas kar ke kharab scan ya dhundle text mein. Pehli quiz ko PDF se ek baar milakar dekh lein.
- API key phone mein save hoti hai. Ye app aap ke apne istemal ke liye theek hai; public app release karni ho to key ko apne server par rakhein.
